import React, { Component } from 'react';
import Fetch_users from "./fetch_users";
export default function App() {
  return <Fetch_users/>;
}

