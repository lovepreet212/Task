import React, { useState, useEffect } from "react";
import { Box, FlatList, Center, NativeBaseProvider, Text } from "native-base";
import {Component, View, StyleSheet } from 'react-native';

export default function Fetch_users() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  this.myref=React.createRef;

  const fetchData = async () => {
    const resp = await fetch("https://dry-harbor-06449.herokuapp.com/schedule");
    const data = await resp.json();
    setData(data);
    setLoading(false);
  };
  var onTime, val1, val2, num1=0, offTime,num2=0;
  const renderItem = ({ item }) => {
    onTime = item.onTime;
    offTime = item.offTime;
    
   if(onTime.includes("am") && offTime.includes("am")){
     num1=onTime.replace("am");
     num2=offTime.replace("am");
     
       }
            
     

     if(onTime.includes("pm") && offTime.includes("pm")){
            
     }
     if(onTime.includes("am") && offTime.includes("pm")){
            
     }
     if(onTime.includes("pm") && offTime.includes("am")){
            
     }
     
     
     
     
   
   
    
   

    return (
      <View>
        <Box px={5} py={2} rounded="md" bg="primary.300" my={2}>
          {item.name} 
        </Box>
        <View style={styles.container}>
        <View id={"12am"} style={styles.button}/>
        <View id={"3am"} style={styles.button}/>
        <View id={"6am"} style={styles.button}/>
        <View id={"9am"} style={styles.button}/>
        <View id={"12pm"} style={styles.button}/>
        <View id={"3pm"} style={styles.button} />
        <View id={"6pm"} style={styles.button} />
        <View id={"9pm"} style={styles.button}/>
        
        </View>
        </View>
        
    );
  };

  const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center'
  },
  button: {
    backgroundColor: '#808080',
    width: '20px',
    height: '50px'
  }
});


  useEffect(() => {
    fetchData();
  }, []);
  return (
    <NativeBaseProvider>
      <Center flex={1}>
        <Box> Fetch API</Box>
        {loading && <Box>Loading..</Box>}
        {data && (
          <FlatList
            data={data}
            renderItem={renderItem}
            keyExtractor={(item) => item.name}
          />
        )}
      </Center>
    </NativeBaseProvider>
  );
}
